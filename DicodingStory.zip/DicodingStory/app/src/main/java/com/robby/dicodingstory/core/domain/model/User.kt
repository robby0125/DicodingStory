package com.robby.dicodingstory.core.domain.model

data class User(
    val userId: String,
    val name: String,
    val token: String
)
